'use strict';

// Daymark keeps everything on the device. No server or account required.
const TASKS_KEY = 'daymark.tasks.v1';
const THEME_KEY = 'daymark.theme.v1';
const VALID_PRIORITIES = new Set(['low', 'medium', 'high']);
const VIEWS = {
  today: { label: 'Today', heading: 'Make today count', subtitle: 'A little progress every day adds up. You’ve got this.' },
  upcoming: { label: 'Upcoming', heading: 'What’s coming up', subtitle: 'A clear view of what’s next, one day at a time.' },
  all: { label: 'All tasks', heading: 'Everything in one place', subtitle: 'See the big picture and keep moving forward.' },
  completed: { label: 'Completed', heading: 'Look how far you’ve come', subtitle: 'Every checked box is progress worth celebrating.' },
};

const $ = (id) => document.getElementById(id);
let tasks = loadTasks();
let view = 'today';
let editingId = null;
let toastTimer;

function localDate(date = new Date()) {
  return [date.getFullYear(), String(date.getMonth() + 1).padStart(2, '0'), String(date.getDate()).padStart(2, '0')].join('-');
}

function offsetDate(days) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return localDate(date);
}

function newId() {
  return typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function demoTasks() {
  return [
    { id: newId(), title: 'Plan priorities for the week', notes: 'Pick the three things that matter most.', date: localDate(), priority: 'high', completed: false, completedAt: null, createdAt: Date.now() - 3000 },
    { id: newId(), title: 'Review the design mockups', notes: 'Leave feedback before the next check-in.', date: localDate(), priority: 'medium', completed: false, completedAt: null, createdAt: Date.now() - 2000 },
    { id: newId(), title: 'Take a proper screen break', notes: 'A little fresh air goes a long way.', date: '', priority: 'low', completed: false, completedAt: null, createdAt: Date.now() - 1000 },
    { id: newId(), title: 'Share the project update', notes: 'Send the latest progress to the team.', date: offsetDate(2), priority: 'medium', completed: false, completedAt: null, createdAt: Date.now() },
  ];
}

function normalizeTask(value) {
  if (!value || typeof value !== 'object' || typeof value.title !== 'string' || !value.title.trim()) return null;
  const completed = value.completed === true;
  return {
    id: typeof value.id === 'string' && value.id ? value.id : newId(),
    title: value.title.trim().slice(0, 120),
    notes: typeof value.notes === 'string' ? value.notes.slice(0, 500) : '',
    date: typeof value.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value.date) ? value.date : '',
    priority: VALID_PRIORITIES.has(value.priority) ? value.priority : 'medium',
    completed,
    completedAt: completed && typeof value.completedAt === 'number' ? value.completedAt : null,
    createdAt: typeof value.createdAt === 'number' ? value.createdAt : Date.now(),
  };
}

function loadTasks() {
  try {
    const saved = localStorage.getItem(TASKS_KEY);
    if (saved !== null) {
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed.map(normalizeTask).filter(Boolean) : [];
    }
  } catch (error) {
    console.warn('Could not load saved tasks:', error);
  }
  return demoTasks();
}

function saveTasks() {
  try {
    localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
  } catch (error) {
    console.warn('Could not save tasks:', error);
    showToast('Unable to save. Check browser storage settings.');
  }
}

function showToast(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.add('visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('visible'), 2600);
}

function prettyDate(value) {
  if (!value) return '';
  const [year, month, day] = value.split('-').map(Number);
  return new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', year: year !== new Date().getFullYear() ? 'numeric' : undefined }).format(new Date(year, month - 1, day));
}

function filteredTasks() {
  const today = localDate();
  const query = $('search-input').value.trim().toLocaleLowerCase();
  const priority = $('priority-filter').value;
  return tasks.filter(task => {
    if (view === 'today' && (task.completed || (task.date && task.date > today))) return false;
    if (view === 'upcoming' && (task.completed || !task.date || task.date <= today)) return false;
    if (view === 'completed' && !task.completed) return false;
    if (priority !== 'all' && task.priority !== priority) return false;
    if (query && !`${task.title} ${task.notes}`.toLocaleLowerCase().includes(query)) return false;
    return true;
  }).sort((a, b) => {
    if (a.completed !== b.completed) return Number(a.completed) - Number(b.completed);
    const aDate = a.date || '9999-12-31';
    const bDate = b.date || '9999-12-31';
    if (aDate !== bDate) return aDate.localeCompare(bDate);
    const weights = { high: 0, medium: 1, low: 2 };
    return weights[a.priority] - weights[b.priority] || b.createdAt - a.createdAt;
  });
}

function makeTaskRow(task) {
  const row = document.createElement('div');
  row.className = `task-row${task.completed ? ' is-complete' : ''}`;

  const check = document.createElement('input');
  check.type = 'checkbox';
  check.className = 'task-checkbox';
  check.checked = task.completed;
  check.setAttribute('aria-label', `Mark ${task.title} as ${task.completed ? 'incomplete' : 'complete'}`);
  check.addEventListener('change', () => {
    task.completed = check.checked;
    task.completedAt = check.checked ? Date.now() : null;
    saveTasks();
    render();
    showToast(check.checked ? 'Nice work! Task completed.' : 'Task moved back to your list.');
  });
  row.append(check);

  const detail = document.createElement('div');
  detail.className = 'task-detail';
  const title = document.createElement('button');
  title.type = 'button';
  title.className = 'task-title edit-title';
  title.textContent = task.title;
  title.title = `Edit ${task.title}`;
  title.setAttribute('aria-label', `Edit task: ${task.title}`);
  title.addEventListener('click', () => openTaskDialog(task));
  detail.append(title);
  if (task.notes) {
    const notes = document.createElement('p');
    notes.className = 'task-notes';
    notes.textContent = task.notes;
    detail.append(notes);
  }
  row.append(detail);

  const meta = document.createElement('div');
  meta.className = 'task-meta';
  const badge = document.createElement('span');
  badge.className = `priority priority-${task.priority}`;
  badge.textContent = `${task.priority[0].toUpperCase()}${task.priority.slice(1)}`;
  meta.append(badge);
  if (task.date) {
    const date = document.createElement('span');
    date.className = `due-date${!task.completed && task.date < localDate() ? ' overdue' : ''}`;
    date.textContent = `${!task.completed && task.date < localDate() ? 'Overdue · ' : ''}${prettyDate(task.date)}`;
    meta.append(date);
  }
  const del = document.createElement('button');
  del.type = 'button';
  del.className = 'delete-button';
  del.textContent = '✕';
  del.setAttribute('aria-label', `Delete task: ${task.title}`);
  del.title = 'Delete task';
  del.addEventListener('click', () => {
    if (!window.confirm(`Delete “${task.title}”? This cannot be undone.`)) return;
    tasks = tasks.filter(item => item.id !== task.id);
    saveTasks();
    render();
    showToast('Task deleted.');
  });
  meta.append(del);
  row.append(meta);
  return row;
}

function render() {
  const today = localDate();
  const open = tasks.filter(task => !task.completed);
  const doneToday = tasks.filter(task => task.completed && task.completedAt != null && localDate(new Date(task.completedAt)) === today);
  const completion = tasks.length ? Math.round(100 * (tasks.length - open.length) / tasks.length) : 0;
  $('open-count').textContent = String(open.length);
  $('done-count').textContent = String(doneToday.length);
  $('progress-number').textContent = `${completion}%`;
  $('progress-fill').style.width = `${completion}%`;
  $('progress-track').setAttribute('aria-valuenow', String(completion));
  $('today-count').textContent = String(open.filter(task => !task.date || task.date <= today).length);

  const config = VIEWS[view];
  $('breadcrumb-view').textContent = config.label;
  $('page-heading').innerHTML = ''; // Static text is added safely below.
  $('page-heading').append(document.createTextNode(config.heading));
  const headingDot = document.createElement('span');
  headingDot.className = 'heading-dot';
  headingDot.textContent = '.';
  $('page-heading').append(headingDot);
  $('page-subtitle').textContent = config.subtitle;
  document.querySelectorAll('.nav-link').forEach(link => {
    const active = link.dataset.view === view;
    link.classList.toggle('active', active);
    if (active) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });

  const shown = filteredTasks();
  $('visible-count').textContent = String(shown.length);
  $('task-list').replaceChildren(...shown.map(makeTaskRow));
  $('task-list').hidden = shown.length === 0;
  $('empty-state').hidden = shown.length > 0;
  const filtered = $('search-input').value.trim() || $('priority-filter').value !== 'all';
  $('empty-title').textContent = filtered ? 'No matching tasks' : view === 'completed' ? 'No completed tasks yet' : view === 'upcoming' ? 'Nothing on the horizon' : 'A fresh start!';
  $('empty-copy').textContent = filtered ? 'Try another search or change the priority filter.' : view === 'completed' ? 'Complete a task to see your wins here.' : 'Nothing here yet. Add a task and start making progress.';
  $('empty-add').hidden = Boolean(filtered) || view === 'completed';
}

function openTaskDialog(task = null) {
  editingId = task?.id ?? null;
  $('task-form').reset();
  $('dialog-heading').textContent = task ? 'Edit task' : 'Create a task';
  $('save-task').textContent = task ? 'Save changes' : 'Create task';
  $('task-title').value = task?.title ?? '';
  $('task-notes').value = task?.notes ?? '';
  $('task-date').value = task?.date || localDate();
  $('task-priority').value = task?.priority ?? 'medium';
  $('task-dialog').showModal();
  $('task-title').focus();
}

function closeTaskDialog() { $('task-dialog').close(); }

function saveTask(event) {
  event.preventDefault();
  const title = $('task-title').value.trim();
  if (!title) { $('task-title').focus(); return; }
  const priority = $('task-priority').value;
  const values = {
    title: title.slice(0, 120),
    notes: $('task-notes').value.trim().slice(0, 500),
    date: $('task-date').value,
    priority: VALID_PRIORITIES.has(priority) ? priority : 'medium',
  };
  if (editingId) {
    const existing = tasks.find(task => task.id === editingId);
    if (existing) Object.assign(existing, values);
  } else {
    tasks.push({ id: newId(), ...values, completed: false, completedAt: null, createdAt: Date.now() });
  }
  const wasEditing = Boolean(editingId);
  closeTaskDialog();
  saveTasks();
  render();
  showToast(wasEditing ? 'Changes saved.' : 'Task added. Let’s make it happen!');
}

function exportTasks() {
  const data = JSON.stringify({ app: 'Daymark', version: 1, exportedAt: new Date().toISOString(), tasks }, null, 2);
  const url = URL.createObjectURL(new Blob([data], { type: 'application/json' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = `daymark-tasks-${localDate()}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  showToast('Your tasks were exported.');
}

function initTheme() {
  try {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === 'dark') document.documentElement.dataset.theme = 'dark';
  } catch (error) { console.warn('Theme storage unavailable:', error); }
}

function toggleTheme() {
  const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = next;
  try { localStorage.setItem(THEME_KEY, next); } catch (error) { console.warn('Theme storage unavailable:', error); }
}

function init() {
  initTheme();
  const now = new Date();
  $('current-date').textContent = new Intl.DateTimeFormat('en', { weekday: 'short', month: 'short', day: 'numeric' }).format(now);
  $('date-pill').textContent = new Intl.DateTimeFormat('en', { weekday: 'long', month: 'long', day: 'numeric' }).format(now);
  document.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click', () => { view = button.dataset.view; render(); }));
  $('search-input').addEventListener('input', render);
  $('priority-filter').addEventListener('change', render);
  $('new-task-button').addEventListener('click', () => openTaskDialog());
  $('empty-add').addEventListener('click', () => openTaskDialog());
  $('task-form').addEventListener('submit', saveTask);
  $('close-dialog').addEventListener('click', closeTaskDialog);
  $('cancel-task').addEventListener('click', closeTaskDialog);
  $('task-dialog').addEventListener('click', (event) => { if (event.target === $('task-dialog')) closeTaskDialog(); });
  $('export-button').addEventListener('click', exportTasks);
  $('theme-toggle').addEventListener('click', toggleTheme);
  document.addEventListener('keydown', event => {
    if (event.key.toLowerCase() !== 'n' || event.metaKey || event.ctrlKey || event.altKey || $('task-dialog').open) return;
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) || document.activeElement?.isContentEditable) return;
    event.preventDefault();
    openTaskDialog();
  });
  render();
}

init();
