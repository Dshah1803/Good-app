# Daymark ✳

A clean, responsive task planner built with **HTML, CSS, and vanilla JavaScript**. No framework, account, build step, or backend needed.

## Features

- Add, edit, complete, and delete tasks
- Due dates, notes, and low/medium/high priorities
- Today, Upcoming, All tasks, and Completed views
- Search and priority filtering
- Completion stats and progress indicator
- Light and dark modes
- Tasks automatically saved in your browser using `localStorage`
- Export task data to a JSON file
- Responsive design for desktop and mobile
- Keyboard shortcut: press **N** to create a task

## Run locally

1. Download or clone this repository.
2. Open `index.html` in your browser.

That's it. Optionally start a local server:

```bash
python3 -m http.server 8000
```

Then visit http://localhost:8000.

## Publish with GitHub Pages

1. Push these files to a GitHub repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Choose `main` and `/ (root)`, then save.

Your site will be available at `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/` once deployment finishes. GitHub Pages requires an eligible repository and plan.

## Data and privacy

Tasks are stored **only in the browser you're using**. They do not sync between devices. Browser storage can be cleared, so use **Export** in the top right to keep a backup. Demo tasks appear the first time you launch the app and can be deleted.

The app uses Google Fonts when online, but it works offline with system font fallbacks.

## Project structure

```text
daymark-app/
├── index.html      # App layout and accessible controls
├── styles.css      # Responsive styles and themes
├── app.js          # Tasks, filters, storage, and interactions
├── favicon.svg     # App icon
├── .gitignore
└── README.md
```

## License

MIT. See [LICENSE](LICENSE).
